---
title: Course requirements and grading
layout: page
menuItem: Course requirements
menuPosition: 3
---
Everything a student needs to know to not to fail. *Too too.*

## Requirements

Use a nice table to present the basics.

<table>
	<tbody>	
		<tr>
			<td class="icon" style="color: red">✎</td>
			<td><b>Position papers</b><br>1 point</td>
			<td>Short description.</td>
		</tr>
		<tr>
			<td class="icon" style="color: orange">♺</td>
			<td><b>Attendance</b><br>1 point</td>
			<td>Short description.</td>
		</tr>
	</tbody>
</table>


### Position papers

All the details.


### Attendance

All the details.


## Grading

There's a maximum score: 100 points.

- 100—90: A
- 89—80: B
- 79—70: C
- …
- less than X: F

There's [a place where the current grading info is kept]({{ site.gradingUrl }}).


## What to do in case of illness etc.

Your policies.
