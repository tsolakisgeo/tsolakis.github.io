---
week: 3
day: September 15
title: Third unit
tags: [deepStuff, science]
---
### Surname, Name: _Book title_

City: Publisher, 2017\. ISBN 123-45-678-9012-3.  
**Required excerpt: p. 55–90 (35 pages). [PDF]({{ site.docsUrl }}article.pdf)**

### Surname, Name: _Article title_  

In: Publication, Date. [Available online.](http://publication.com/article_url)  
**Entire article required (~5 pages). [PDF]({{ site.docsUrl }}cached-to-be-sure.pdf)**
